<?php

return [
    'delivery_fee' => (float) env('DELIVERY_FEE', 0),
];
